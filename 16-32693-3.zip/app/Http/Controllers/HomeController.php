<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Users;
use App\User;
use Validator;
use App\Http\Requests\UserRequest;

class HomeController extends Controller
{


    public function index(Request $req){
		return view('home.index');
	}

    public function add(){
    	return view('home.add');
    }

    public function create(UserRequest $req){

/*        $this->validate($req, [

            "uname"     => "required | unique:users,username",
            "password"  => "required|min:8",
            "name"      => "required",
            "dept"      => "required",
            "cgpa"      => "required"
        ]);*/

/*        $req->validate([

            "uname"     => "required | unique:users,username",
            "password"  => "required|min:8",
            "name"      => "required",
            "dept"      => "required",
            "cgpa"      => "required"
        ]);*/

/*        $validator = Validator::make($req->all(), [

            "uname"     => "required | unique:users,username",
            "password"  => "required|min:8",
            "name"      => "required",
            "dept"      => "required",
            "cgpa"      => "required"
        ])->validate();*/
        
        //$validator->validate();

        /*if($validator->fails()){

            //dd($validator);
            return back()
                    ->with('errors', $validator->errors());
        } */     

    	$users = new Users();
       
    	$users->ename = $req->ename;
        $users->cname = $req->cname;
        $users->contact = $req->contact;
    	$users->uname = $req->uname;
    	$users->password = $req->password;
    	$users->type = "user";
    	$users->save();

    	//$data = User::where('uname', $req->uname)->where('password', $req->password)->get();
    	return redirect()->route('home.emplist');
    }

	public function details(){

		
		return view('home.details');
    }

    public function search(Request $req){

        $search = $req->get('search');
        $emp= DB::table('users')->where('uname',$search);
        return view('home.search', ['emp'=>$emp]);
    }

    // public function viewsearch(){

        
    //     return view('home.search');
    // }




    public function show(){

    	$empList = Users::all();

        //return json($stdlist);
    	return view('home.emplist', ['emp'=> $empList]);
    }
	
	public function edit($id){

		$emp = Users::find($id);
		return view('home.edit', ['emp'=>$emp]);
    }

    public function update(Request $req, $id){

    	$users = Users::find($id);

    	$users->ename = $req->ename;
    	$users->cname = $req->cname;
        $users->contact = $req->contact;
        $users->uname = $req->uname;
    	$users->password = $req->password;
   
    	$users->save();

		return redirect()->route('home.emplist');
    }
	public function delete($id){

		$emp = Users::find($id);
		return view('home.delete', ['emp'=>$emp]);
    }

    public function destroy($id){

		Users::destroy($id);
		return redirect()->route('home.emplist');
	}

    

    
       
}




