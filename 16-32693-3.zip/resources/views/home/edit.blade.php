
<!DOCTYPE html>
<html>
<head>
	<title>Edit Employee</title>
</head>
<body>

	<h2>Edit Employee</h2>

	<a href="{{route('home.emplist')}}">Back</a> |
	<a href="/logout">logout</a>

<form method="post">
	@csrf
	<table border="0">
		<tr>
			<td>Id</td>
			<td>{{$emp['id']}}</td>
		</tr>
		<tr>
			<td>Employee Name</td>
			<td><input type="text" name="ename" value="{{$emp['ename']}}"></td>
		</tr>
		<tr>
			<td>Company Name</td>
			<td><input type="text" name="cname" value="{{$emp['cname']}}"></td>
		</tr>
		<tr>
			<td>Contact</td>
			<td><input type="text" name="contact" value="{{$emp['contact']}}"></td>
		</tr>
		<tr>
			<td>Username</td>
			<td><input type="text" name="uname" value="{{$emp['uname']}}"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="text" name="password" value="{{$emp['password']}}"></td>
		</tr>
		
			<td></td>
			<td><input type="submit" name="save" value="Save"></td>
		</tr>
</table>
</form>
</body>
</html>