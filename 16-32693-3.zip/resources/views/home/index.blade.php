<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Welcome Home! {{session('user')}}</h1> 

	
	
	<a href="{{route('home.add')}}">Add Employee</a> |
	<a href="{{route('home.emplist')}}">Employee List</a> |
	<a href="{{route('home.details')}}">Search Employee</a> |
	<a href="/logout">logout</a>


</body>
</html>