
<!DOCTYPE html>
<html>
<head>
	<title>Delete Student</title>
</head>
<body>

	<h2>Delete Employee</h2>

	<a href="{{route('home.emplist')}}">Back</a> |
	<a href="/logout">logout</a>

<form method="post">
	@csrf
	<table border="0">
		<tr>
			<td>Id :</td>
			<td>{{$emp['id']}}</td>
		</tr>
		<tr>
			<td>Employee Name :</td>
			<td>{{$emp['ename']}}</td>
		</tr>
		<tr>
			<td>Company Name :</td>
			<td>{{$emp['cname']}}</td>
		</tr>
		<tr>
			<td>Username :</td>
			<td>{{$emp['uname']}}</td>
		</tr>
		<tr>
			<td>Contact :</td>
			<td>{{$emp['contact']}}</td>
		</tr>
		
		
</table>
	<h3>Are you sure?</h3>
	<input type="submit" name="delete" value="Confirm">
</form>
</body>
</html>