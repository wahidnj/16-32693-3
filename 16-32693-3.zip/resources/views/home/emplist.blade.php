<!DOCTYPE html>
<html>
<head>
	<title>Employee List</title>
</head>
<body>

	<h2>Employee List:</h2>
	
	<a href="/home">Back</a> |
	<a href="/logout">logout</a>

	<table border="1">
		<tr>
			<td>Employee Name</td>
			<td>Company Name</td>
			<td>Contact</td>
			<td>Username</td>

		</tr>
		@foreach($emp as $value)
		<tr>
			<td>{{$value['ename']}}</td>
			<td>{{$value['cname']}}</td>
			<td>{{$value['contact']}}</td>
			<td>{{$value['uname']}}</td>
			<td>
				<a href="{{route('home.edit', $value['id'])}}">Edit</a> |
				<a href="{{route('home.delete', $value['id'])}}">Delete</a> 
			</td>
		</tr>
		@endforeach

</table>

</body>
</html>