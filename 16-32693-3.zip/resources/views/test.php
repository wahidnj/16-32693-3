<!DOCTYPE html>
<html>
<head>
	<title>Laravel Test View</title>
</head>
<body>

	<h1>Hello Laravel</h1>
</body>
</html>