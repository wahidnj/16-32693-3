
<!DOCTYPE html>
<html>
<head>
	<title>Edit Employee</title>
</head>
<body>

	<h2>Edit Employee</h2>

	<a href="{{route('employee.joblist')}}">Back</a> |
	<a href="/logout">logout</a>

<form method="post">
	@csrf
	<table border="0">
		<tr>
			<td>Job Id</td>
			<td>{{$job['jid']}}</td>
		</tr>
		<tr>
			<td>Company Name</td>
			<td><input type="text" name="cname" value="{{$job['cname']}}"></td>
		</tr>
		<tr>
			<td>Job Title</td>
			<td><input type="text" name="jtitle" value="{{$job['jtitle']}}"></td>
		</tr>
		<tr>
			<td>Location</td>
			<td><input type="text" name="jlocation" value="{{$job['jlocation']}}"></td>
		</tr>
		<tr>
			<td>Salary</td>
			<td><input type="text" name="salary" value="{{$job['salary']}}"></td>
		</tr>
		
		
			<td></td>
			<td><input type="submit" name="save" value="Save"></td>
		</tr>
</table>
</form>
</body>
</html>