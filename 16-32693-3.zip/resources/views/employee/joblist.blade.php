<!DOCTYPE html>
<html>
<head>
	<title>Job List</title>
</head>
<body>

	<h2>Job List:</h2>
	
	<a href="{{route('employee.index')}}">Back</a> |
	<a href="/logout">logout</a>

	<table border="1">
		<tr>
			<td>Job ID</td>
			<td>Company Name</td>
			<td>Job Title</td>
			<td>Location</td>
			<td>Salary</td>

		</tr>
		@foreach($job as $value)
		<tr>
			<td>{{$value['jid']}}</td>
			<td>{{$value['cname']}}</td>
			<td>{{$value['jtitle']}}</td>
			<td>{{$value['jlocation']}}</td>
			<td>{{$value['salary']}}</td>
			<td>
				<a href="{{route('employee.edit', $value['jid'])}}">Edit</a> |
				<a href="{{route('employee.delete', $value['jid'])}}">Delete</a> 
				
			</td>
		</tr>
		@endforeach

</table>

</body>
</html>