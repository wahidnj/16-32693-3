<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Welcome Home! {{session('user')}}</h1> 

	
	
	<a href="{{route('employee.add')}}">Add Job</a> |
	<a href="{{route('employee.joblist')}}">Job List</a> |
	<a href="/logout">logout</a>


</body>
</html>